import java.util.InputMismatchException;
import java.util.Scanner;

class Circle {
    private double radius;

    // Default constructor
    public Circle() {
        radius = 0.0;
    }

    // Accessor for radius
    public double getRadius() {
        return radius;
    }

    // Mutator for radius
    public void setRadius(double radius) {
        if (radius >= 0) {
            this.radius = radius;
        } else {
            System.out.println("Invalid input: Radius cannot be negative.");
        }
    }

    // Calculate and return the area of the circle
    public double calculateArea() {
        return Math.PI * radius * radius;
    }

    // Override toString() to print the radius of the circle
    @Override
    public String toString() {
        return "Radius of the circle: " + radius;
    }
}

public class App {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Circle circle = new Circle();

        while (true) {
            try {
                System.out.print("Enter the radius of the circle (enter a negative number or a string to exit): ");
                if (scanner.hasNextDouble()) {
                    double radius = scanner.nextDouble();
                    if (radius >= 0) {
                        circle.setRadius(radius);
                        System.out.println(circle.toString());
                        System.out.println("Area of the circle: " + circle.calculateArea());
                    } else {
                        System.out.println("Exiting the program.");
                        break;
                    }
                } else {
                    String input = scanner.next();
                    System.out.println("Exiting the program.");
                    break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input: Please enter a valid number.");
                scanner.nextLine(); // Consume the invalid input
            }
        }

        scanner.close();
    }
}
