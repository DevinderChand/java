import java.util.ArrayList;

/**
 * Checkout class for maintaining a list of items
 */
public class Checkout {
    private ArrayList<Item> items;

    public Checkout() {
        this.items = new ArrayList<>();
    }

    public void enterItem(Item item) {
        items.add(item);
    }

    public void clear() {
        items.clear();
    }

    public int numberOfItems() {
        return items.size();
    }

    public int totalCost() {
        int total = 0;
        for (Item item : items) {
            total += item.getCost();
        }
        return total;
    }

    public int totalTax() {
        double taxRate = SheridanBookStore.TAX_RATE / 100.0;
        return (int) Math.round(totalCost() * taxRate);
    }

    @Override
    public String toString() {
        StringBuilder receipt = new StringBuilder();
        receipt.append("\t").append(SheridanBookStore.STORE_NAME).append("\n");
        receipt.append("------------------------------------\n");
        receipt.append("1.25 lbs. @ 3.99 /lb.\n");
    
        for (Item item : items) {
            String itemName = item.getName();
            String itemCost = SheridanBookStore.centsToDollarsAndCents(item.getCost());
            receipt.append(String.format("%-25s %6s\n", itemName, itemCost));


        // Add the "4 @ 3.99 /dz." line after the "C++ Book" entry
        if (itemName.equals("C++ book")) {
            receipt.append(String.format("%-25s %6s\n", "4 @ 3.99 /dz.", " "));
        }
        }
    
        receipt.append(String.format("\nNumber of items: %d\n", numberOfItems()));
        receipt.append(String.format("\nTotal cost: %-27s\n", SheridanBookStore.centsToDollarsAndCents(totalCost())));
        receipt.append(String.format("\nTotal tax: %-27s\n", SheridanBookStore.centsToDollarsAndCents(totalTax())));
        receipt.append(String.format("\nCost + Tax: %-27s\n", SheridanBookStore.centsToDollarsAndCents(totalCost() + totalTax())));


        return receipt.toString();
    }
    

}