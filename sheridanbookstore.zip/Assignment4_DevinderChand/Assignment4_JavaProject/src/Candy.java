/**
 * Candy class derived from Item
 */
public class Candy extends Item {
    private double weight;
    private int pricePerPound;

    public Candy(String name, double weight, int pricePerPound) {
        super(name);
        this.weight = weight;
        this.pricePerPound = pricePerPound;
    }

    @Override
    public int getCost() {
        return Math.round((float) (weight * pricePerPound));
    }
}
