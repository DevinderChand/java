/**
 * Main method to test Checkout class and Item hierarchy
 */
public class TestCheckout {
    public static void main(String[] args) {
        Checkout checkout = new Checkout();
        checkout.enterItem(new Candy("Smarties", 1.25, 399));
        checkout.enterItem(new Book("Java book", 1005));
        checkout.enterItem(new Book("C++ book", 999));
        checkout.enterItem(new Pencil("XYZ Lead Pencil", 4, 399));

        System.out.println("\nExpected Output:\n");
        System.out.println("\tSheridanBookStore\n" +
                "------------------------------------");
        System.out.println("1.25 lbs. @ 3.99 /lb.\nSmarties\t\t4.98");
        System.out.println("Java book\t\t10.05");
        System.out.println("C++ Book\t\t9.99");
        System.out.println("4 @ 3.99 /dz.\nXYZ Lead Pencil\t\t1.33\n");
        System.out.println("Number of items: 4\n");
        System.out.println("Total cost: 26.35\n");
        System.out.println("Total tax: 1.71\n");
        System.out.println("Cost + Tax: 28.06\n");

        System.out.println("Actual Output:\n");
        System.out.println(checkout);

        checkout.clear();
    }
}
