/**
 * Book class derived from Item
 */
public class Book extends Item {
    private int cost;

    public Book(String name, int cost) {
        super(name);
        this.cost = cost;
    }

    @Override
    public int getCost() {
        return cost;
    }
}
