/**
 * Pencil class derived from Item
 */
public class Pencil extends Item {
    private int number;
    private int pricePerDozen;

    public Pencil(String name, int number, int pricePerDozen) {
        super(name);
        this.number = number;
        this.pricePerDozen = pricePerDozen;
    }

    @Override
    public int getCost() {
        return Math.round((float) (number * pricePerDozen / 12.0));
    }
}
